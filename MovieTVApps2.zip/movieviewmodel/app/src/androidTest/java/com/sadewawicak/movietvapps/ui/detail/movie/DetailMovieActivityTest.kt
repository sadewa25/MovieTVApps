package com.sadewawicak.movietvapps.ui.detail.movie

import android.content.Context
import android.content.Intent
import androidx.test.espresso.Espresso
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import com.sadewawicak.movietvapps.R
import com.sadewawicak.movietvapps.data.MovieEntity
import com.sadewawicak.movietvapps.utils.FakeDataDummy
import org.junit.Rule
import org.junit.Test

class DetailMovieActivityTest{

    private val movieEntity: MovieEntity = FakeDataDummy().generateMovies().get(0)

    @Rule @JvmField
    var activityRule: ActivityTestRule<DetailMovieActivity> = object : ActivityTestRule<DetailMovieActivity>(DetailMovieActivity::class.java) {
        override fun getActivityIntent(): Intent {
            val targetContext: Context = InstrumentationRegistry.getInstrumentation().getTargetContext()
            val result = Intent(targetContext, DetailMovieActivity::class.java)
            result.putExtra("id", movieEntity.idMovie)
            return result
        }
    }

    @Test
    fun loadCourse() {
        Espresso.onView(ViewMatchers.withId(R.id.text_title))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.text_title))
            .check(ViewAssertions.matches(ViewMatchers.withText(movieEntity.title)))
        Espresso.onView(ViewMatchers.withId(R.id.text_date))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.text_date)).check(ViewAssertions.matches(ViewMatchers.withText("${movieEntity.genre} - ${movieEntity.date}")))

    }

}