package com.sadewawicak.movietvapps.ui.detail.tv

import android.content.Context
import android.content.Intent
import androidx.test.espresso.Espresso
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.rule.ActivityTestRule
import com.sadewawicak.movietvapps.R
import com.sadewawicak.movietvapps.data.TVShowEntity
import com.sadewawicak.movietvapps.utils.FakeDataDummy
import com.sadewawicak.movietvapps.utils.RecyclerViewItemCountAssertion
import org.junit.Rule
import org.junit.Test

class DetailTVActivityTest{

    private val tvEntity: TVShowEntity = FakeDataDummy().generateTVs().get(0)

    @Rule
    @JvmField
    var activityRule: ActivityTestRule<DetailTVActivity> = object : ActivityTestRule<DetailTVActivity>(DetailTVActivity::class.java) {
        override fun getActivityIntent(): Intent {
            val targetContext: Context = InstrumentationRegistry.getInstrumentation().getTargetContext()
            val result = Intent(targetContext, DetailTVActivity::class.java)
            result.putExtra("id", tvEntity.idTVs)
            return result
        }
    }

    @Test
    fun loadCourse() {
        Espresso.onView(ViewMatchers.withId(R.id.text_title))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.text_title))
            .check(ViewAssertions.matches(ViewMatchers.withText(tvEntity.titleTV)))
        Espresso.onView(ViewMatchers.withId(R.id.text_date))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.text_date)).check(ViewAssertions.matches(ViewMatchers.withText("${tvEntity.genre} - ${tvEntity.releaseDate}")))
    }

    @Test
    fun loadModules() {
        Espresso.onView(ViewMatchers.withId(R.id.rv_episode))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(R.id.rv_episode)).check(RecyclerViewItemCountAssertion(5))
    }

}