package com.sadewawicak.movietvapps.data

data class EpisodeEntity(
    val idEpisode:String,
    val idTVs:String,
    val titleEpisode:String,
    val descEpisode:String
)