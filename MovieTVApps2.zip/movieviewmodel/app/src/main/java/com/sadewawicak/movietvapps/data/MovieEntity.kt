package com.sadewawicak.movietvapps.data

data class MovieEntity(
    val idMovie:String,
    val title:String,
    val overview:String,
    val genre:String,
    val date:String,
    val brosur:String
)