package com.sadewawicak.movietvapps.data

data class TVShowEntity (
    val idTVs:String,
    val titleTV:String,
    val genre:String,
    val releaseDate:String,
    val overview:String,
    val brosur:String
)