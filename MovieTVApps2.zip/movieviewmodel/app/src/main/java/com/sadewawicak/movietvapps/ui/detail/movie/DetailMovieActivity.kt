package com.sadewawicak.movietvapps.ui.detail.movie

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProviders
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.sadewawicak.movietvapps.R
import com.sadewawicak.movietvapps.data.MovieEntity
import kotlinx.android.synthetic.main.content_detail_movie.*

class DetailMovieActivity : AppCompatActivity() {

    private lateinit var detailMovieViewModel: DetailMovieViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        detailMovieViewModel = ViewModelProviders.of(this).get(DetailMovieViewModel::class.java)
        detailMovieViewModel.setIDMovies(intent?.getStringExtra("id"))

        bindMovies(detailMovieViewModel.getMovies())

    }

    private fun bindMovies(movieEntity: MovieEntity?) {
        text_title.text = movieEntity?.title
        text_date.text = "${movieEntity?.genre} - ${movieEntity?.date}"
        text_description.text = movieEntity?.overview

        Glide.with(applicationContext)
            .load(movieEntity?.brosur)
            .apply(RequestOptions.placeholderOf(R.mipmap.ic_launcher).error(R.drawable.ic_error))
            .into(image_poster)

    }

}
