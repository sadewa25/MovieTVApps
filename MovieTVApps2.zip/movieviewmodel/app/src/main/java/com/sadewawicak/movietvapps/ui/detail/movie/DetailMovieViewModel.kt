package com.sadewawicak.movietvapps.ui.detail.movie

import androidx.lifecycle.ViewModel
import com.sadewawicak.movietvapps.data.MovieEntity
import com.sadewawicak.movietvapps.utils.DataDummy

class DetailMovieViewModel:ViewModel() {

    private var idMovies: String? = null
    private var mMovies:MovieEntity? = null

    fun getMovies(): MovieEntity? {
        for (i in DataDummy().generateMovies().indices) {
            val movieEntity: MovieEntity = DataDummy().generateMovies().get(i)
            if (movieEntity.idMovie == idMovies) {
                mMovies = movieEntity
            }
        }
        return mMovies
    }

    fun setIDMovies(idMovies: String?) {
        this.idMovies = idMovies
    }
}