package com.sadewawicak.movietvapps.ui.detail.tv

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.sadewawicak.movietvapps.R
import com.sadewawicak.movietvapps.data.TVShowEntity
import com.sadewawicak.movietvapps.ui.detail.tv.episode.EpisodesAdapter
import kotlinx.android.synthetic.main.content_detail_tv.*

class DetailTVActivity : AppCompatActivity() {

    private lateinit var viewModel: DetailTVViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_tv)

        viewModel = ViewModelProviders.of(this).get(DetailTVViewModel::class.java)

        viewModel.setIDTVs(intent.getStringExtra("id"))
        bindTVs(viewModel.getTVs())

    }

    private fun bindTVs(model: TVShowEntity?) {
        text_title.text = model?.titleTV
        text_date.text = "${model?.genre} - ${model?.releaseDate}"
        text_description.text = model?.overview

        text_list_episode.text = "${resources?.getString(R.string.title_episode)} - ${model?.titleTV}"

        Glide.with(applicationContext)
            .load(model?.brosur)
            .apply(RequestOptions.placeholderOf(R.mipmap.ic_launcher).error(R.drawable.ic_error))
            .into(image_poster)

        val adapter = EpisodesAdapter(applicationContext)
        adapter.setListEpisodes(viewModel.getEpisodes(intent?.getStringExtra("id").toString()))
        rv_episode.layoutManager = LinearLayoutManager(applicationContext)
        rv_episode.setHasFixedSize(true)
        rv_episode.adapter = adapter

    }

}
