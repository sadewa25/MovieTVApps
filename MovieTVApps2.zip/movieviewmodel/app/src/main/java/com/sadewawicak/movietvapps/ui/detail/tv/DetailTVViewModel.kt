package com.sadewawicak.movietvapps.ui.detail.tv

import androidx.lifecycle.ViewModel
import com.sadewawicak.movietvapps.data.EpisodeEntity
import com.sadewawicak.movietvapps.data.TVShowEntity
import com.sadewawicak.movietvapps.utils.DataDummy

class DetailTVViewModel:ViewModel() {

    private var idTVs: String? = null
    private var mTVs:TVShowEntity? = null

    fun getTVs(): TVShowEntity? {
        for (i in DataDummy().generateTVs().indices) {
            val movieEntity: TVShowEntity = DataDummy().generateTVs().get(i)
            if (movieEntity.idTVs == idTVs) {
                mTVs = movieEntity
            }
        }
        return mTVs
    }

    fun getEpisodes(idTVs:String):ArrayList<EpisodeEntity>{
        return DataDummy().generateEpisode(idTVs)
    }

    fun setIDTVs(idMovies: String?) {
        this.idTVs = idMovies
    }


}