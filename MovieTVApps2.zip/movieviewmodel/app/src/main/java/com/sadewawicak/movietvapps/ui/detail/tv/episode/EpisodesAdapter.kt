package com.sadewawicak.movietvapps.ui.detail.tv.episode

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sadewawicak.movietvapps.R
import com.sadewawicak.movietvapps.data.EpisodeEntity

class EpisodesAdapter (val activity: Context?): RecyclerView.Adapter<EpisodesAdapter.AcademyViewHolder>() {

    var mEpisodes:ArrayList<EpisodeEntity> = arrayListOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AcademyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.items_episode_list, parent, false)
        return AcademyViewHolder(view)
    }

    private fun getListEpisodes(): List<EpisodeEntity> {
        return mEpisodes
    }

    fun setListEpisodes(mMovies: List<EpisodeEntity>?) {
        if (mMovies == null) return
        this.mEpisodes.clear()
        this.mEpisodes.addAll(mMovies)
    }

    override fun onBindViewHolder(holder: AcademyViewHolder, position: Int) {
        holder.bindData(activity,getListEpisodes().get(position))
    }

    override fun getItemCount(): Int {
        return getListEpisodes().size
    }


    class AcademyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle = itemView.findViewById<TextView>(R.id.text_episode_title)
        val tvDesc = itemView.findViewById<TextView>(R.id.text_episode_desc)

        fun bindData(activity: Context?,data:EpisodeEntity){
            tvTitle.setText(data.titleEpisode)
            tvDesc.setText(data.descEpisode)
        }

    }

}