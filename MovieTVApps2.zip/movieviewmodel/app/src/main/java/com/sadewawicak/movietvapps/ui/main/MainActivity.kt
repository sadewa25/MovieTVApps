package com.sadewawicak.movietvapps.ui.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProviders
import com.sadewawicak.movietvapps.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var viewmodel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewmodel = ViewModelProviders.of(this).get(MainViewModel::class.java)

        viewmodel.setupViewPager(applicationContext,viewpager_main,supportFragmentManager)
        tabs_main.setupWithViewPager(viewpager_main)
    }
}
