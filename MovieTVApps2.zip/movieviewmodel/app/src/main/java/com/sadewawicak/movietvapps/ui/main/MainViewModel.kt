package com.sadewawicak.movietvapps.ui.main

import android.content.Context
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.ViewModel
import androidx.viewpager.widget.ViewPager
import com.sadewawicak.movietvapps.R
import com.sadewawicak.movietvapps.ui.movie.MovieFragment
import com.sadewawicak.movietvapps.ui.tv.TVShowFragment

class MainViewModel:ViewModel() {

    fun setupViewPager(context:Context,viewPager: ViewPager, manager: FragmentManager?){
        val adapter =
            MainViewPager(manager!!)
        adapter.addFragment(
            MovieFragment(), context.getString(
                R.string.title_movie
            ))
        adapter.addFragment(
            TVShowFragment(), context.getString(
                R.string.title_tvshow
            ).toString())
        viewPager.adapter = adapter
    }

}