package com.sadewawicak.movietvapps.ui.movie

import androidx.lifecycle.ViewModel
import com.sadewawicak.movietvapps.data.MovieEntity
import com.sadewawicak.movietvapps.utils.DataDummy

class MovieViewModel :ViewModel(){

    fun getMovies():ArrayList<MovieEntity>{
        return DataDummy().generateMovies()
    }

}