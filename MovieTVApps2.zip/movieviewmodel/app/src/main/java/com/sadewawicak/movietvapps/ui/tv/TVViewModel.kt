package com.sadewawicak.movietvapps.ui.tv

import androidx.lifecycle.ViewModel
import com.sadewawicak.movietvapps.data.TVShowEntity
import com.sadewawicak.movietvapps.utils.DataDummy

class TVViewModel:ViewModel() {

    fun getTVShows():ArrayList<TVShowEntity>{
        return DataDummy().generateTVs()
    }

}