package com.sadewawicak.movietvapps.ui.detail.movie

import com.sadewawicak.movietvapps.data.MovieEntity
import junit.framework.Assert
import org.junit.Test

import org.junit.Before

class DetailMovieViewModelTest {

    private var viewModel: DetailMovieViewModel? = null
    private var movieEntity: MovieEntity? = null

    @Before
    fun init(){
        viewModel = DetailMovieViewModel()
        movieEntity = MovieEntity(
            "b2",
            "Inception",
            "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
            "Action, Adventure, Sci-Fi",
            "16 July 2010 (Indonesia)",
            "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_UX182_CR0,0,182,268_AL_.jpg"
        )
    }

    @Test
    fun getCourse() {
        viewModel?.setIDMovies(movieEntity?.idMovie)
        val movieEntity = viewModel?.getMovies()
        Assert.assertNotNull(movieEntity)
        Assert.assertEquals(this.movieEntity?.idMovie, movieEntity?.idMovie)
        Assert.assertEquals(this.movieEntity?.brosur, movieEntity?.brosur)
        Assert.assertEquals(this.movieEntity?.genre, movieEntity?.genre)
        Assert.assertEquals(this.movieEntity?.date, movieEntity?.date)
        Assert.assertEquals(this.movieEntity?.overview, movieEntity?.overview)
        Assert.assertEquals(this.movieEntity?.title, movieEntity?.title)
    }

}