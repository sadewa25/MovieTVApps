package com.sadewawicak.movietvapps.ui.detail.tv

import com.sadewawicak.movietvapps.data.TVShowEntity
import junit.framework.Assert
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class DetailTVViewModelTest{

    private var viewModel: DetailTVViewModel? = null
    private var tvEntity: TVShowEntity? = null

    @Before
    fun init(){
        viewModel = DetailTVViewModel()
        tvEntity = TVShowEntity(
            "v6",
            "Rick and Morty",
            "Animation, Adventure, Comedy",
            "TV Series (2013– )",
            "An animated series that follows the exploits of a super scientist and his not-so-bright grandson.",
            "https://m.media-amazon.com/images/M/MV5BMjRiNDRhNGUtMzRkZi00MThlLTg0ZDMtNjc5YzFjYmFjMmM4XkEyXkFqcGdeQXVyNzQ1ODk3MTQ@._V1_UY268_CR2,0,182,268_AL_.jpg"
        )
    }

    @Test
    fun getCourse() {
        viewModel?.setIDTVs(tvEntity?.idTVs)
        val tvEntity = viewModel?.getTVs()
        Assert.assertNotNull(tvEntity)
        Assert.assertEquals(this.tvEntity?.idTVs, tvEntity?.idTVs)
        Assert.assertEquals(this.tvEntity?.brosur, tvEntity?.brosur)
        Assert.assertEquals(this.tvEntity?.genre, tvEntity?.genre)
        Assert.assertEquals(this.tvEntity?.releaseDate, tvEntity?.releaseDate)
        Assert.assertEquals(this.tvEntity?.overview, tvEntity?.overview)
        Assert.assertEquals(this.tvEntity?.titleTV, tvEntity?.titleTV)

        assertEquals(5, viewModel?.getEpisodes(this.tvEntity?.idTVs.toString())?.size)

    }

}