package com.sadewawicak.movietvapps.ui.tv

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class TVViewModelTest {

    private lateinit var viewModel:TVViewModel

    @Before
    fun init(){
        viewModel = TVViewModel()
    }

    @Test
    fun getTVShows() {
        val TVEntity = viewModel.getTVShows()
        assertNotNull(TVEntity)
        assertEquals(12, TVEntity.size)
    }
}